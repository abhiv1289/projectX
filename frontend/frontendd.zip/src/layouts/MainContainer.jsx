import React from "react";
import Home from "../views/Home";

const MainContainer = () => {
  return (
    <div className="w-full">
      <Home />
    </div>
  );
};

export default MainContainer;
